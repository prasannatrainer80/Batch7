function redColor() {
    document.bgColor = "red";
}

function blueColor() {
    document.bgColor = "blue";
}

function greenColor() {
    document.bgColor = "green";
}